module Test
  module Unit
    VERSION = "3.2.7"
  end
end
