#!/usr/bin/env node

const say = require('../')

// no callback, fire and forget
say.speak('whats up, dog?', 'Alex')
